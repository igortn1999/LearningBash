#include <stdio.h>

int main(void){
    printf("this is a program");
    return 0;
}
